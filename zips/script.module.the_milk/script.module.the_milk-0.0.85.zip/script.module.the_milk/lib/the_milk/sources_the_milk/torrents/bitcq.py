# -*- coding: utf-8 -*-
# created by Venom for Fenomscrapers (updated 6-19-2022)
"""
	Fenomscrapers Project
"""

import re
from urllib.parse import quote_plus, unquote_plus
from the_milk.modules import client
from the_milk.modules import source_utils
from the_milk.modules import workers
from the_milk.modules import log_utils

SERVER_ERROR = ('something went wrong', 'Connection timed out', '521: Web server is down', '503 Service Unavailable')


class source:
    name = 'bitcq'
    priority = 3
    pack_capable = True
    has_movies = True
    has_episodes = True

    def __init__(self):
        self.language = ['en', 'fr']
        self.base_link = "https://bitcq.com"
        self.search_link = "/search?q=%s&category[]=1"
        self.min_seeders = 0
        self.debug = True

    def _debug_it(self, msg, caller=None):
        if self.debug:
            log_utils.log('BITCQ | %s' % msg, caller, 1)

    def sources(self, data, host_dict):
        sources = []
        if not data: return sources
        sources_append = sources.append
        try:
            aliases = data['aliases']
            year = data['year']

            if 'tvshowtitle' in data:
                title = data['tvshowtitle'].replace('&', 'and').replace('/', ' ').replace('$', 's')
                title = title + ' french '
                episode_title = data['title']
                hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
            else:
                title = data['title'].replace('&', 'and').replace('/', ' ').replace('$', 's')
                title = title + ' french '
                episode_title = None
                hdlr = year

            query = '%s %s' % (re.sub(r'[^A-Za-z0-9\s\.-]+', '', title), hdlr)
            url = '%s%s' % (self.base_link, self.search_link % quote_plus(query))

            results = client.request(url, timeout=7)

            if not results or any(value in str(results) for value in SERVER_ERROR): return \
                sources

            rows = client.parseDOM(results, 'tr')
            undesirables = source_utils.get_undesirables()
            check_foreign_audio = source_utils.check_foreign_audio()

        except Exception as e:
            source_utils.scraper_error('BITCQ')
            return sources

        for row in rows:
            try:
                if 'magnet:' not in row: continue
                columns = re.findall(r'<td.*?>(.+?)</td>', row, re.DOTALL)

                url = unquote_plus(columns[0]).replace('&amp;', '&')
                try:
                    url = re.search(r'(magnet:.+?)&tr=', url, re.I).group(1).replace(' ', '.')
                except:
                    continue

                hash = re.search(r'btih:(.*?)&', url, re.I).group(1)
                name = source_utils.clean_name(url.split('&dn=')[1])

                if not source_utils.check_title(title, aliases, name, hdlr, year):
                    continue
                name_info = source_utils.info_from_name(name, title, year, hdlr, episode_title)
                if source_utils.remove_lang(name_info, check_foreign_audio):
                    continue
                if undesirables and source_utils.remove_undesirables(name_info, undesirables):
                    continue

                if not episode_title:  # filter for eps returned in movie query (rare but movie and show exists for Run in 2020)
                    ep_strings = [r'(?:\.|\-)s\d{2}e\d{2}(?:\.|\-|$)', r'(?:\.|\-)s\d{2}(?:\.|\-|$)',
                                  r'(?:\.|\-)season(?:\.|\-)\d{1,2}(?:\.|\-|$)']

                    name_lower = name.lower()
                    if any(re.search(item, name_lower) for item in ep_strings):
                        continue

                try:
                    seeders = int(columns[4].replace(',', ''))
                    if self.min_seeders > seeders:
                        continue
                except:
                    seeders = 0

                quality, info = source_utils.get_release_quality(name_info, url)
                try:
                    dsize, isize = source_utils._size(columns[3])
                    info.insert(0, isize)
                except:
                    dsize = 0
                info = ' | '.join(info)

                sources_append(
                    {'provider': 'bitcq', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name,
                     'name_info': name_info,
                     'quality': quality, 'language': 'en', 'url': url, 'info': info, 'direct': False,
                     'debridonly': True, 'size': dsize})

            except:
                source_utils.scraper_error('BITCQ')

        return sources


    def sources_packs(self, data, host_dict, search_series=False, total_seasons=None, bypass_filter=False):
        self.sources = []
        if not data:
            return self.sources

        self.sources_append = self.sources.append
        try:
            self.search_series = search_series
            self.total_seasons = total_seasons
            self.bypass_filter = bypass_filter
            self.title = data['tvshowtitle'].replace('&', 'and').replace('/', ' ').replace('$', 's')
            self.title = self.title + ' french '
            self.aliases = data['aliases']
            self.imdb = data['imdb']
            self.year = data['year']
            self.season_x = data['season']
            self.season_xx = self.season_x.zfill(2)

            self.undesirables = source_utils.get_undesirables()
            self.check_foreign_audio = source_utils.check_foreign_audio()

            query = re.sub(r'[^A-Za-z0-9\s\.-]+', '', self.title)

            queries = [
                self.search_link % quote_plus(query + ' S%s' % self.season_xx),
                self.search_link % quote_plus(query + ' Season %s' % self.season_x)]
            if search_series:
                queries = [
                    self.search_link % quote_plus(query + ' Season'),
                    self.search_link % quote_plus(query + ' Complete')]
            threads = []
            append = threads.append

            for url in queries:
                link = '%s%s' % (self.base_link, url)
                append(workers.Thread(self.get_sources_packs, link))

            [i.start() for i in threads]
            [i.join() for i in threads]
            return self.sources

        except:
            source_utils.scraper_error('GLODLS')
            return self.sources


    def get_sources_packs(self, link):

        try:
            results = client.request(link, timeout=7)
            if not results or any(value in str(results) for value in SERVER_ERROR):
                return
            rows = client.parseDOM(results, 'tr')

        except:
            source_utils.scraper_error('BITCQ')
            return

        for row in rows:
            try:
                if 'magnet:' not in row:
                    continue
                columns = re.findall(r'<td.*?>(.+?)</td>', row, re.DOTALL)

                url = unquote_plus(columns[0]).replace('&amp;', '&')
                try:
                    url = re.search(r'(magnet:.+?)&tr=', url, re.I).group(1).replace(' ', '.')
                except:
                    continue

                hash = re.search(r'btih:(.*?)&', url, re.I).group(1)
                name = source_utils.clean_name(url.split('&dn=')[1])

                episode_start, episode_end = 0, 0
                if not self.search_series:
                    if not self.bypass_filter:
                        valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases,
                                                                                            self.year, self.season_x,
                                                                                            name)
                        if not valid:
                            continue
                    package = 'season'

                elif self.search_series:
                    if not self.bypass_filter:
                        valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb,
                                                                           self.year, self.season_x, name,
                                                                           self.total_seasons)
                        if not valid:
                            continue
                    else:
                        last_season = self.total_seasons
                    package = 'show'

                name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
                if source_utils.remove_lang(name_info, self.check_foreign_audio):
                    continue
                if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables):
                    continue

                try:
                    seeders = int(columns[4].replace(',', ''))
                    if self.min_seeders > seeders:
                        continue
                except:
                    seeders = 0

                quality, info = source_utils.get_release_quality(name_info, url)
                try:
                    dsize, isize = source_utils._size(columns[3])
                    info.insert(0, isize)
                except:
                    dsize = 0

                info = ' | '.join(info)
                item = {'provider': 'bitcq', 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name,
                        'name_info': name_info, 'quality': quality,
                        'language': 'en', 'url': url, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize,
                        'package': package}

                if self.search_series:
                    item.update({'last_season': last_season})
                elif episode_start:
                    item.update(
                        {'episode_start': episode_start, 'episode_end': episode_end})  # for partial season packs

                self.sources_append(item)
            except:
                source_utils.scraper_error('BITCQ')
