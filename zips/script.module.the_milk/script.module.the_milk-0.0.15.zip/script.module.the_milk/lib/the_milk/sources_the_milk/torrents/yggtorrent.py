# -*- coding: utf-8 -*-
# Fork of Projects from Venom Fenomscrapers, TikiPeter FEN, CocoJoe2411 cocoscrapers
# French Torrent yggtorrent.do

import re
from enum import Enum
from urllib.parse import quote_plus, quote
from the_milk.modules import client
from the_milk.modules import source_utils
from the_milk.modules import workers
from the_milk.modules import log_utils
from the_milk.modules.cleantitle import normalize
# from libs.web_pdb import WebPdb

class cats(Enum):
    all = '&sub_category=all'
    films = '&sub_category=2183'
    animations = '&sub_category=2178'
    docus = '&sub_category=2181'
    spectacles = '&sub_category=2185'
    concerts = '&sub_category=2180'
    series = '&sub_category=2184'
    series_animations = '&sub_category=2179'

class source:
    priority = 5
    pack_capable = True
    has_movies = True
    has_episodes = True

    def __init__(self):
        self.language = ['fr']
        self.base_link = 'https://www3.yggtorrent.do/engine/search?category=2145'    # film/video
        self.min_seeders = 0
        self.debug = False
        self._debug_it('Init')


    def _debug_it(self, msg, caller=None):
        if self.debug:
            log_utils.log('yggTorrent | %s' % msg, caller, 1)

    def _make_link(self, title, cat=cats.all, season=None, episode=None):
        url = ''
        if not title or len(title) == 0:
            return url
        search_title = '&do=search&name=%s' % title

        if cat is cats.all:
            url = self.base_link + cats.all.value + search_title

        elif cat is cats.films:
            url = self.base_link + cats.films.value + search_title

        elif cat is cats.docus:
            url = self.base_link + cats.docus.value + search_title

        elif cat is cats.concerts:
            url = self.base_link + cats.concerts.value + search_title

        elif cat is cats.spectacles:
            url = self.base_link + cats.spectacles.value + search_title

        elif cat is cats.animations:
            url = self.base_link + cats.animations.value + search_title

        elif cat is cats.series:
            opt_season, opt_episode = '', ''
            if season:
                opt_season = '&option_saison[]=%s' % str(int(season) + 3)         #  '', 'série intégrale', 'hors saison', 'Non communiqué', 'saison 01' etc...
                if episode:
                    opt_episode = '&option_episode[]=%s' % str(int(episode) + 1)  #  '', 'saison complete', 'episode 01', etc...
            url = self.base_link + cats.series.value + opt_season + opt_episode + search_title

        elif cat is cats.series_animations:
            opt_season, opt_episode = '', ''
            if season:
                opt_season = '&option_saison[]=%s' % str(int(season) + 3)
                if episode:
                    opt_episode = '&option_episode[]=%s' % str(int(episode) + 1)
            url = self.base_link + cats.series_animations.value + opt_season + opt_episode + search_title
        else:
            pass    # url encoder & filter
        return quote_plus(url, ':/?&=')

    def _is_animation(self, genre):
        if genre and 'animation' in genre.lower():
            return True
        else:
            return False

    def sources(self, data, host_dict):
        self.sources = []
        if not data:
            self._debug_it('sources: no data')
            return self.sources

        self.sources_append = self.sources.append
        try:
            self.aliases = data['aliases']
            flag_animation = self._is_animation(data['genre'])
            original_title = data['original_title']
            self._debug_it('sources: flag_animation= %s' % flag_animation)
            self._debug_it('sources: original_title = %s' % original_title)

            if 'tvshowtitle' in data:
                l_title = data['tvshowtitle'].lower().replace('/', '-').replace('$', 's')
                self.title = normalize(l_title)
                self.episode_title = data['title'].lower()
                self.is_movie = False
                self.year = ''
                self.hdlr = 'S%02dE%02d' % (int(data['season']), int(data['episode']))
                self.years = None
            else:
                l_title = data['title'].lower().replace('/', '-').replace('$', 's').replace('!', '')
                self.title = normalize(l_title)
                self.episode_title = None
                self.is_movie = True
                self.year = data['year']
                self.hdlr = self.year
                try:
                    self.years = [str(int(self.year)), str(int(self.year)-1), str(int(self.year) + 1)]
                except:
                    self.years = None

            self._debug_it('sources: LT=%s T=%s Y=%s H=%s A=%s' % (l_title, self.title, self.year, self.hdlr, self.aliases))
            links = []

            if self.is_movie:
                if flag_animation:
                    link = self._make_link(l_title, cats.animations)
                    links.append(link)
                    link = self._make_link(original_title, cats.animations)
                    links.append(link)
                else:
                    link = self._make_link(l_title, cats.films)
                    links.append(link)
                    link = self._make_link(original_title, cats.films)
                    links.append(link)
            else:
                if flag_animation:
                    link = self._make_link(l_title, cats.series_animations, data['season'], data['episode'])
                else:
                    link = self._make_link(l_title, cats.series, data['season'], data['episode'])
                links.append(link)  # title only

            self._debug_it('sources: links= %s' % links)
            self.undesirables = source_utils.get_undesirables()

            threads = []
            append = threads.append

            for link in links:
                append(workers.Thread(self.get_sources, link))

            [i.start() for i in threads]
            [i.join() for i in threads]
            return self.sources
        except Exception as e:
            source_utils.scraper_error('yygTorrent %s' % str(e))
            return self.sources

    def get_sources(self, link):
        link = re.sub(r'[\n\t]', '', link)

        try:
            results = client.request(link, timeout=5)
        except Exception as e:
            log_utils.error('get_sources: Exception https request search item %s' % str(e))
            return

        if not results or 'Aucun résultat !' in results:
            self._debug_it('get_sources: link = %s' % link)
            self._debug_it('get_sources: Aucun résultat !')
            return

        if '<tbody' not in results:
            return

        table = client.parseDOM(results, 'tbody')
        if not table or len(table) < 2:
            return
        table = table[1]

        rows = client.parseDOM(table, 'tr')
        if not rows:
            return
        self._debug_it('get_sources: tr parsing done rows=%s' % len(rows))
        self._debug_it('-')

        for row in rows:

            td = client.parseDOM(row, 'td')
            if not td or len(td) < 2:
                continue

            part = td[1].split('">')
            if len(part) < 2 or len(part[1]) == 0:
                continue

            if 'href="https://' in part[0]:
                url = part[0].split('href="')[1]
                url = quote_plus(url, ':/?&=')
            else:
                url = ''
                continue

            name = normalize(part[1]).replace('version longue', '').replace('extended', '').replace('complete', '').replace('integrale', '')
            if 'vostfr' in name or 'vost.en-fr' in name or 'subfrench' in name or 'cfemail' in name:
                continue

            year_str = re.findall("19\d\d|20\d\d", name)
            if year_str:
                year_str = year_str[0]

            name_info = source_utils.info_from_name(name, self.title, self.year, self.hdlr, self.episode_title)
            self._debug_it('get_sources: name_info=%s' % name_info)

            if not self.is_movie:
                tmp_name = re.sub(".19\d\d|.20\d\d", '', name)
            else:
                tmp_name = name

            self._debug_it('get_sources: T=%s N=%s TN=%s H=%s' % (self.title, name,tmp_name, self.hdlr))

            if not source_utils.check_title(self.title, self.aliases, tmp_name, self.hdlr, self.year, self.years):
                self._debug_it('get_sources: check_title FAILED!  T=%s FT=%s H=%s Y=%s YS=%s' % (
                self.title, name, self.hdlr, self.year, self.years))

                continue

            self._debug_it('get_sources: check_title OK!  T=%s FT=%s Y=%s A=%s' % (self.title, name, self.year, self.aliases))

            try:
                result_html = client.request(url, timeout=5)
            except Exception as e:
                log_utils.error('Exception https request page infos %s' % str(e))
                continue

            if not result_html or '<td>Info Hash</td>' not in result_html:
                self._debug_it('get_sources: info_hash not present!')
                continue
            else:
                self._debug_it('get_sources: infoHash found!')

            tbody = client.parseDOM(result_html, 'tbody')
            if not tbody or len(tbody) < 2:
                continue

            self._debug_it('get_sources: parsing done')
            seeders, dsize, isize, quality, info = 0, 0, 0, '', ''
            tr = client.parseDOM(tbody[0], 'tr')
            if len(tr) < 2:
                continue
            try:
                seeders = int(re.findall('<td><strong class="green">(.*?)</strong></td>', tr[2])[0])
            except:
                seeders = 0

            quality, info = source_utils.get_release_quality(name_info, None)
            trx = client.parseDOM(tbody[1], 'tr')
            if len(trx) < 2:
                continue

            try:
                dsize, isize = source_utils._size(re.findall('<td>(.*?)</td>', trx[3])[1])
                info.insert(0, isize)
            except:
                dsize = 0
                info = ' | '.join(info)
            try:
                info_hash = re.findall('<td>(.*?)</td>', trx[4])[1]
            except:
                continue

            if len(info_hash) == 32:
                try:
                    hash40 = source_utils.base32_to_hex(info_hash, 'get_sources')
                except Exception as e:
                    self._debug_it('get_sources: base32_to_hex %' % str(e))
                    continue
            else:
                hash40 = info_hash
            but_magnet_link = 'magnet:?xt=urn:btih:%s' % hash40

            self.sources_append(
                {'provider': 'yggtorrent', 'source': 'torrent', 'seeders': seeders, 'hash': hash40, 'name': name, 'name_info': name_info,
                 'quality': quality, 'language': 'fr', 'url': but_magnet_link, 'info': info, 'direct': False, 'debridonly': True, 'size': dsize})

            self._debug_it('APPEND name= %s' % name)
            self._debug_it('APPEND quality= %s size= %s' % (quality, isize))
            self._debug_it('APPEND magnet= %s' % but_magnet_link)
            self._debug_it(
                'APPEND seeders= %s hash= %s name= %s nameInfo= %s quality= %s size=%s url= %s' % (
                    seeders, hash40, name, name_info, quality, isize, but_magnet_link))
            self._debug_it('-')

    def sources_packs(self, data, host_dict, search_series=False, total_seasons=None, bypass_filter=False):
        self.sources = []
        if not data:
            return self.sources

        self._debug_it('sources_packs')
        self.sources_append = self.sources.append
        flag_animation = self._is_animation(data['genre'])
        self._debug_it('sources_packs: flag_animation= %s' % flag_animation)

        try:
            self.search_series = search_series
            self.total_seasons = total_seasons
            self.bypass_filter = bypass_filter

            l_title = data['tvshowtitle'].lower().replace('/', ' ').replace('$', 's')
            self.title = normalize(l_title)
            self.aliases = data['aliases']
            self.imdb = data['imdb']
            self.year = data['year']
            self.season_x = data['season']
            self.season_xx = self.season_x.zfill(2)
            self.undesirables = source_utils.get_undesirables()
            self.check_foreign_audio = source_utils.check_foreign_audio()

            if flag_animation:
                link = self._make_link(l_title, cats.series_animations, data['season'], None)
            else:
                link = self._make_link(l_title, cats.series, data['season'], None)

            self._debug_it('sources_packs: link= %s' % link)

            threads = []
            append = threads.append
            append(workers.Thread(self.get_sources_packs, link))

            [i.start() for i in threads]
            [i.join() for i in threads]
            return self.sources

        except Exception as e:
            self._debug_it('sources_packs: Exception %s' % str(e))
            return self.sources

    def get_sources_packs(self, link):
        link = re.sub(r'[\n\t]', '', link)

        try:
            results = client.request(link, timeout=5)
        except Exception as e:
            log_utils.error('get_sources_packs: Exception https request search item %s' % str(e))
            return

        if not results or 'Aucun résultat !' in results:
            self._debug_it('get_sources_packs: link = %s' % link)
            self._debug_it('get_sources_packs: Aucun résultat !')
            return

        if '<tbody' not in results:
            return

        table = client.parseDOM(results, 'tbody')
        if not table or len(table) < 2:
            return
        table = table[1]

        rows = client.parseDOM(table, 'tr')
        if not rows:
            return
        self._debug_it('get_sources_packs: tr parsing done rows=%s' % len(rows))
        self._debug_it('-')

        for row in rows:

            td = client.parseDOM(row, 'td')
            if not td or len(td) < 2:
                continue

            part = td[1].split('">')
            if len(part) < 2 or len(part[1]) == 0:
                continue

            if 'href="https://' in part[0]:
                url = part[0].split('href="')[1]
                url = quote_plus(url, ':/?&=')

            name = normalize(part[1]).replace('version longue', '').replace('extended', '').replace('complete', '').replace('integrale', '')
            if 'vostfr' in name or 'vost.en-fr' in name or 'subfrench' in name or 'cfemail' in name:
                continue

            year_str = re.findall("19\d\d|20\d\d", name)
            if year_str:
                year_str = year_str[0]

            tmp_name = re.sub(".19\d\d|.20\d\d", '', name)
            self._debug_it('get_sources_packs: T=%s N=%s' % (self.title, name))

            episode_start, episode_end, valid = 0, 0, False
            if not self.search_series:
                if not self.bypass_filter:
                    valid, episode_start, episode_end = source_utils.filter_season_pack(self.title, self.aliases, self.year, self.season_x, tmp_name)
                    if not valid:
                        continue
                package = 'season'
            elif self.search_series:
                if not self.bypass_filter:
                    valid, last_season = source_utils.filter_show_pack(self.title, self.aliases, self.imdb, self.year, self.season_x, tmp_name, self.total_seasons)
                if not valid:
                    continue
            else:
                last_season = self.total_seasons
                package = 'show'

            self._debug_it('get_sources_packs: check_title OK!  T=%s FT=%s Y=%s A=%s' % (self.title, name, self.year, self.aliases))


            try:
                result_html = client.request(url, timeout=5)
            except Exception as e:
                log_utils.error('Exception https request page infos %s' % str(e))
                continue

            if not result_html or '<td>Info Hash</td>' not in result_html:
                continue

            tbody = client.parseDOM(result_html, 'tbody')
            if not tbody or len(tbody) < 2:
                continue

            self._debug_it('get_sources_packs: parsing done')
            name_info = source_utils.info_from_name(name, self.title, self.year, season=self.season_x, pack=package)
            self._debug_it('get_sources_packs: name_info=%s' % name_info)

            seeders, dsize, isize, quality, info = 0, 0, 0, '', ''
            tr = client.parseDOM(tbody[0], 'tr')
            if len(tr) < 2:
                continue
            try:
                seeders = int(re.findall('<td><strong class="green">(.*?)</strong></td>', tr[2])[0])
            except:
                seeders = 0

            quality, info = source_utils.get_release_quality(name_info, None)
            trx = client.parseDOM(tbody[1], 'tr')
            if len(trx) < 2:
                continue

            try:
                dsize, isize = source_utils._size(re.findall('<td>(.*?)</td>', trx[3])[1])
                info.insert(0, isize)
            except:
                dsize = 0
                info = ' | '.join(info)
            try:
                info_hash = re.findall('<td>(.*?)</td>', trx[4])[1]
            except:
                continue

            if len(info_hash) == 32:
                try:
                    hash40 = source_utils.base32_to_hex(info_hash, 'get_sources')
                except:
                    continue
            else:
                hash40 = info_hash
            but_magnet_link = 'magnet:?xt=urn:btih:%s' % hash40

            item = {'provider': 'yggtorrent', 'source': 'torrent', 'seeders': seeders, 'hash': hash40, 'name': name,
                    'name_info': name_info, 'quality': quality,
                    'language': 'fr', 'url': but_magnet_link, 'info': info, 'direct': False, 'debridonly': True,
                    'size': dsize,
                    'package': package}

            self._debug_it('APPEND PACKS name= %s' % name)
            self._debug_it('APPEND PACKS quality= %s size= %s' % (quality, isize))
            self._debug_it('APPEND PACKS magnet= %s' % but_magnet_link)
            self._debug_it('APPEND PACKS seeders= %s hash= %s name= %s nameInfo= %s quality= %s size= %s url= %s' % (
                seeders, hash40, name, name_info, quality, isize, but_magnet_link))
            self._debug_it('-')

            if self.search_series:
                item.update({'last_season': last_season})

            elif episode_start:
                item.update({'episode_start': episode_start, 'episode_end': episode_end})  # for partial season packs

            self.sources_append(item)

    def main(self):
        from the_milk.modules.test_modules import Tests
        tests = Tests()
        #self.sources(tests.data_movie_1(), '')
        #self.sources(tests.data_movie_2(), '')
        #self.sources(tests.data_movie_3(), '')
        #self.sources(tests.data_movie_4(), '')
        #self.sources(tests.data_serie_1(), '')
        #self.sources(tests.data_serie_2(), '')
        self.sources(tests.data_serie_3(), '')

        #self.sources_packs(tests.data_serie_packs_1(), '')
        #self.sources_packs(tests.data_serie_packs_2(), '')

if __name__ == "__main__":
    ygg = source()
    ygg.main()
