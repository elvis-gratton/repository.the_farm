﻿# -*- coding: utf-8 -*-

import xbmc, xbmcgui, xbmcvfs, xbmcaddon
from time import time
import json
import requests
import shutil
from os import path as osPath
from zipfile import ZipFile
from the_milk.modules.control import  setting as get_setting

executebuiltin = xbmc.executebuiltin
execute_JSON = xbmc.executeJSONRPC
translatePath = xbmcvfs.translatePath
Log, Window = xbmc.log, xbmcgui.Window
xbmc_monitor, xbmc_player = xbmc.Monitor, xbmc.Player

addon_object = xbmcaddon.Addon('script.module.the_milk')
addon_info   = addon_object.getAddonInfo
addon_icon   = translatePath(addon_info('icon'))
delete, path_exists = xbmcvfs.delete, xbmcvfs.exists
xbmc_sleep = xbmc.sleep
window, dialog = Window(10000), xbmcgui.Dialog()

addon_dir = 'script.module.the_milk'
destination_check = translatePath('special://home/addons/script.module.the_milk/')
home_addons_dir = translatePath('special://home/addons/')
packages_dir = translatePath('special://home/addons/packages/')

heading_str = 'La pinte de lait | Updateur'
success_str = '[CR]Succes.[CR]La pinte de lait a Change pour la version [B]%s[/B]'
error_update_str = 'Erreur pendant le Updating.[CR]S.v.p. installer le nouveau update manuellement'
no_changes_str = 'Vous avez presentement la version a date de la pinte de lait.[CR][CR]Aucune nouvelle version de changelog a voir.'
update_available_str = '[B]Un Update est Disponible[/B][CR]Faire le  Update?'
result_str = 'Version Installee: [B]%s[/B][CR]Version en ligne: [B]%s[/B][CR][CR] %s'
view_changes_str = 'Nouvelle version disponible [B](v.%s)[/B].[CR]Voulez vous voir les changelog avant l`installation?'
no_update_str = '[B]Pas de Update Disponible[/B]'

notification_available_str = 'La pinte de lait | Update Disponible'
notification_occuring_str  = 'La pinte de lait | Update en Cours'

#####################################################################################################################
class UpdateCheck:
	def run(self):
		if get_property('themilk.firstrun_update') == 'true':
			return
		end_pause = time() + 45
		monitor, player = xbmc_monitor(), xbmc_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo

		while not monitor.abortRequested():
			while time() < end_pause:
				wait_for_abort(1)
			while get_property('themilk.pause_services') == 'true' or is_playing():
				wait_for_abort(1)
			update_check(update_enabled())
			break
		set_property('themilk.firstrun_update', 'true')
		try:
			del monitor
		except:
			pass
		try:
			del player
		except:
			pass
		return

#####################################################################################################################
def update_enabled():	# {'0': 'Demander avant', '1': 'Automatique', '2': 'Notification', '3': 'Off'}
	if get_setting('update.enabled', 'true'):
		return 1
	else:
		return 3

def get_property(prop):
	return window.getProperty(prop)

def set_property(prop, value):
	return window.setProperty(prop, value)

def sleep(time):
	return xbmc_sleep(time)

def string_alphanum_to_num(string):
	try: 
		return ''.join(c for c in string if c.isdigit())
	except ValueError: 
		return string
			
def unzip(zip_location, destination_location, destination_check, show_busy=True):
	try:
		zipfile = ZipFile(zip_location)
		zipfile.extractall(path=destination_location)
		if path_exists(destination_check): 
			status = True
		else: 
			status = False
	except: 
		status = False
	return status

def notification(line1, time=5000, icon=None):
	icon = icon or addon_icon
	dialog.notification('La pinte de lait', line1, icon, time)

#####################################################################################################################
 
def update_kodi_addons_db(addon_name='script.module.the_milk'):
	import time
	import sqlite3 as database
	try:
		date = time.strftime('%Y-%m-%d %H:%M:%S')
		dbcon = database.connect(translatePath('special://database/Addons33.db'), timeout=40.0)
		dbcon.execute("INSERT OR REPLACE INTO installed (addonID, enabled, lastUpdated) VALUES (?, ?, ?)", (addon_name, 1, date))
		dbcon.close()
	except: pass
		
def update_local_addons():
	executebuiltin('UpdateLocalAddons', True)
	sleep(2500)		

def disable_enable_addon(addon_name='script.module.the_milk'):
	try:
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': False}}))
		execute_JSON(json.dumps({'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled', 'params': {'addonid': addon_name, 'enabled': True}}))
	except: pass

#####################################################################################################################
def close_all_dialog():
	executebuiltin('Dialog.Close(all,true)')

def confirm_dialog(line, heading='Are you sure?', yeslabel='OK', nolabel='Cancel'):
	return dialog.yesno(heading, line, nolabel, yeslabel)

def ok_dialog(title=None, message=None):
	heading = str(title)
	body = str(message)
	return dialog.ok(heading, body)
    	
#####################################################################################################################

def update_check(action=4): # {'0': 'Demander avant', '1': 'Automatique', '2': 'Notification', '3': 'Off'}
	if action == 3:
		return
	current_version, online_version = get_versions()
	if not current_version:
		return
	if not version_check(current_version, online_version):
		if action == 4:
			return ok_dialog(heading_str, result_str % (current_version, online_version, no_update_str))
		return
	if action in (0, 4):
		if not confirm_dialog(heading=heading_str, text=result_str % (current_version, online_version, update_available_str), ok_label='Yes', cancel_label='No'):
			return
	if action == 1:
		notification(notification_occuring_str)
	elif action == 2:
		return notification(notification_available_str)
	return update_addon(online_version, action)

def get_versions():
	try:
		result = requests.get('https://github.com/elvis-gratton/elvis-gratton.github.io/raw/master/packages/the_milk_version')
		if result.status_code != 200:
			return None, None
		online_version = result.text.replace('\n', '')
		current_version = addon_info('version')
		return current_version, online_version
	except:
		return None, None

def version_check(current_version, online_version):
	return string_alphanum_to_num(current_version) != string_alphanum_to_num(online_version)


def update_addon(new_version, action): # {'0': 'Demander avant', '1': 'Automatique', '2': 'Notification', '3': 'Off'}
	close_all_dialog()
	executebuiltin('ActivateWindow(Home)', True)
	notification('La pinte de lait | update en cours', icon=None)

	# url link for addon zip
	zip_name = 'script.module.the_milk-%s.zip' % new_version
	url = 'https://github.com/elvis-gratton/elvis-gratton.github.io/raw/master/packages/%s' % zip_name

	# Download zip file
	result = requests.get(url, stream=True)

	if result.status_code != 200:
		return ok_dialog(heading_str, error_update_str)

	# copy file to folder special://home/addons/packages/
	zip_location = osPath.join(packages_dir, zip_name)
	with open(zip_location, 'wb') as f: shutil.copyfileobj(result.raw, f)

	# delete tree of the old addon
	shutil.rmtree(osPath.join(home_addons_dir, addon_dir))

	# unzip content of the zip to the folder addon ex: special://home/addons/plugin.video.the_milk/
	success = unzip(zip_location, home_addons_dir, destination_check)

	# delete addon zipfile in the folder special://home/addons/packages/
	delete(zip_location)
	if not success:
		return ok_dialog(heading_str, error_update_str)

	update_local_addons()
	disable_enable_addon()
	update_kodi_addons_db()